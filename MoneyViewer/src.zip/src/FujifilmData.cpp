//
//
//

#include "pch.h"
#include "FujifilmData.h"
using namespace std;

//
//�R���X�g���N�^
//
FujifilmData::FujifilmData()
{

}

//
//
//
FujifilmData::~FujifilmData()
{

}

//
//
//
string FujifilmData::Id()
{
    return this->id;
}

//
//
//
string FujifilmData::Name()
{
    return this->name;
}