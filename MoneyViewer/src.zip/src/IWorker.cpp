#include "pch.h"
#include "IWorker.h"


string IWorker::Id()
{
    //��
    return "";
}

string IWorker::Name()
{
    return "";
}

int IWorker::Money()
{
    return 0;
}

//vector<string> IWorker::lineDatas()
//{
//    vector<string> tmp;
//    return tmp;
//}