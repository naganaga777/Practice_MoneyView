#pragma once
#ifndef FUJIFILMDATA
#define FUJIFILMDATA

#include "IData.h"
#include "pch.h"
#include  <iostream>

using namespace std;

class FujifilmData :IData
{
public:
    FujifilmData();
    ~FujifilmData();

private:
    string id;
    string name;
    int money;

public:
    string  Id();
    string Name();
    
};
#endif // !FUJIFILMDATA

